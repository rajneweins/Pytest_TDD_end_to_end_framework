class Config:
    LOGIN_URL = "https://portal.azure.com/"
    USERNAME = "token"
    DATABRICKS_TOKEN = "dapi021dbba23035eff62ef3117d5601d00c-3"
    SERVER_HOSTNAME = "adb-7581078081855566.6.azuredatabricks.net"
    HTTP_PATH = "sql/protocolv1/o/7581078081855566/0913-041730-disie6al"
    DRIVER = "{Simba Spark ODBC Driver}"
    PORT = 443
    SSL_CA = 'C:/Program Files/Simba Spark ODBC Driver/lib/cacerts.pem'
    WORKSPACE_URL = 'https://adb-7581078081855566.6.azuredatabricks.net'
    CLUSTER_ID = '0913-041730-disie6al'
    SILVER_JOB_ID = 514276375765557
