class TestData:
    VALID_USERNAME = "malijeddi.gowtham@honeywell.com"
    VALID_PASSWORD = "Mg@9177654320"
    TITLE = "Microsoft Azure"
    DURATION = 8
    REASON = "TESTING"

